var x=10
if (x>5){
	console.log("The value of x is greater than 5")
}