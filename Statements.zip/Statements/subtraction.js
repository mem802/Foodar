var x=3;
var y=7;
var z = "Result: ";
var z=x-y;

console.log("Result: " + z);