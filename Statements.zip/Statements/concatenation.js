var firstname="Mary Elizabeth";
var lastname=" Montgomery";
console.log(firstname+lastname);